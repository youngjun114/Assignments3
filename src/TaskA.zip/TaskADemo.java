// Youngjun Woo
// CS 240
// Assignment 3
// May 18, 2018

public class TaskADemo {

    public static void main(String[] args){

        Integer[] array = {5, 7, 4, 9, 8, 5, 6, 3};
        System.out.println("Before sorting");
        SelectionSort.display(array, array.length);
        SelectionSort.selectionSort(array, array.length);
        System.out.println();

        Integer[] array2 = {5, 7, 4, 9, 8, 5, 6, 3};
        System.out.println("Before sorting");
        InsertionSort.display(array2, array2.length);
        InsertionSort.insertionSort(array2, array2.length);

    }
}
