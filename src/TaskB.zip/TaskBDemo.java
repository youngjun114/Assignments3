// Youngjun Woo
// CS 240
// Assignment 3
// May 18, 2018

public class TaskBDemo {
    public static void main(String[] args){
        Integer[] array = {5, 7, 4, 8, 9, 6, 5, 3};
        System.out.println("Before Sorting");
        ReverseSelectionSort.display(array, array.length);
        System.out.println();
        System.out.println("After Reverse Sorting");
        ReverseSelectionSort.selectionSort(array, array.length);

    }
}


/*
Output:

Before Sorting
5	7	4	8	9	6	5	3

After Reverse Sorting
9	7	4	8	5	6	5	3
9	8	4	7	5	6	5	3
9	8	7	4	5	6	5	3
9	8	7	6	5	4	5	3
9	8	7	6	5	4	5	3
9	8	7	6	5	5	4	3
9	8	7	6	5	5	4	3
*/